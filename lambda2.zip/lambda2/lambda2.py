import json
import base64
import boto3
import pytesseract
from PIL import Image
import io
import os

# Initialize AWS Textract client
textract = boto3.client('textract')

# Set the Tesseract binary path
pytesseract.pytesseract.tesseract_cmd = "/opt/tesseract/bin/tesseract"  # Update based on your layer

def lambda_handler(event, context):
    try:
        # Parse the incoming payload
        if 'body' in event:
            # If invoked via API Gateway
            body = json.loads(event['body'])
        else:
            # Direct invocation
            body = event

        image_b64 = body.get('image', '').strip()

        if not image_b64:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'The "image" field is required and cannot be empty.'})
            }

        # Decode the Base64 image
        try:
            image_bytes = base64.b64decode(image_b64, validate=True)
        except (base64.binascii.Error, ValueError):
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'The "image" field must be a valid base64-encoded string.'})
            }

        # Perform OCR using Amazon Textract
        textract_text = ""
        textract_confidences = []
        try:
            textract_response = textract.detect_document_text(
                Document={'Bytes': image_bytes}
            )
            for item in textract_response.get('Blocks', []):
                if item['BlockType'] == 'LINE':
                    textract_text += item['Text'] + '\n'
                    textract_confidences.append(item.get('Confidence', 0))
            textract_text = textract_text.strip()
            # Calculate average confidence
            if textract_confidences:
                textract_avg_confidence = sum(textract_confidences) / len(textract_confidences)
            else:
                textract_avg_confidence = 0
        except Exception as e:
            textract_text = ""
            textract_avg_confidence = 0
            print(f"Textract Error: {str(e)}")

        # Perform OCR using pytesseract
        pytesseract_text = ""
        pytesseract_confidences = []
        try:
            image = Image.open(io.BytesIO(image_bytes))
            # Perform OCR with pytesseract to get detailed data
            pytesseract_data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            num_boxes = len(pytesseract_data['level'])
            for i in range(num_boxes):
                word = pytesseract_data['text'][i].strip()
                conf = int(pytesseract_data['conf'][i])
                if word:
                    pytesseract_text += word + ' '
                    pytesseract_confidences.append(conf)
            pytesseract_text = pytesseract_text.strip()
            # Calculate average confidence
            if pytesseract_confidences:
                pytesseract_avg_confidence = sum(pytesseract_confidences) / len(pytesseract_confidences)
            else:
                pytesseract_avg_confidence = 0
        except Exception as e:
            pytesseract_text = ""
            pytesseract_avg_confidence = 0
            print(f"pytesseract Error: {str(e)}")

        # Compare accuracies and select the best result
        if textract_avg_confidence >= pytesseract_avg_confidence:
            selected_text = textract_text
        else:
            selected_text = pytesseract_text

        return {
            'statusCode': 200,
            'body': json.dumps({
                'text': selected_text
            }),
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error during OCR processing.',
                'error': str(e)
            }),
        }
